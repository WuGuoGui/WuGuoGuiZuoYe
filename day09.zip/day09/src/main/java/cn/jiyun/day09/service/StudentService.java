package cn.jiyun.day09.service;

import cn.jiyun.day09.entity.Student;

import java.util.List;

/**
 * ClassName: StudentService
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:54
 * Version: 1.0
 * Description:
 */
public interface StudentService {
    List<Student> findAll();

    Object add(Student student);

    Object edit(Student student);

    Object delete(Integer id);
}
