package cn.jiyun.day09.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ClassName: Student
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:56
 * Version: 1.0
 * Description:
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    private Integer stuId;
    private String stuName;
    private Integer stuAge;
    private String stuOrigin;
    private String stuAddress;
    private String stuPhone;
    private Classs classs;
}
