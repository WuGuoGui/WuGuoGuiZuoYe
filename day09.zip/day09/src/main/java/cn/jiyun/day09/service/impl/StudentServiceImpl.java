package cn.jiyun.day09.service.impl;

import cn.jiyun.day09.dao.StudentDao;
import cn.jiyun.day09.entity.Student;
import cn.jiyun.day09.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * ClassName: StudentServiceImpl
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:54
 * Version: 1.0
 * Description:
 */
@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;

    @Override
    public List<Student> findAll() {
        return studentDao.findAll();
    }

    @Override
    public Object add(Student student) {
        int a = 0;
        int b = 0;
        a = studentDao.addStudent(student);
        int stuId = studentDao.selectStuIdByStuName(student.getStuName());
        b = studentDao.addStudentClasss(stuId,student.getClasss().getClaId());
        return a*b>0;
    }

    @Override
    public Object edit(Student student) {
        int a = 0;
        int b = 0;
        int c = 0;
        a = studentDao.editStudent(student);
        c = studentDao.deleteStudentClasss(student.getStuId());
        b = studentDao.addStudentClasss(student.getStuId(),student.getClasss().getClaId());
        return a*b*c>0;
    }

    @Override
    public Object delete(Integer id) {
        int a = 0;
        int b = 0;
        a = studentDao.deleteStudentClasss(id);
        b = studentDao.deleteStudent(id);
        return a*b>0;
    }


}
