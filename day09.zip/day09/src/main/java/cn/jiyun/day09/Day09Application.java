package cn.jiyun.day09;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "cn.jiyun.day09.dao")
public class Day09Application {

    public static void main(String[] args) {
        SpringApplication.run(Day09Application.class, args);
    }

}
