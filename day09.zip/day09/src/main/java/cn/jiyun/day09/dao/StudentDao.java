package cn.jiyun.day09.dao;

import cn.jiyun.day09.entity.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * ClassName: StudentDao
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:55
 * Version: 1.0
 * Description:
 */
public interface StudentDao {
    List<Student> findAll();

    int addStudent(Student student);

    int selectStuIdByStuName(String stuName);

    int addStudentClasss(@Param("a") int stuId,@Param("b") Integer claId);

    int editStudent(Student student);

    int deleteStudentClasss(Integer stuId);

    int deleteStudent(Integer id);
}
