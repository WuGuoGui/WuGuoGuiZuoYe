package cn.jiyun.day09.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ClassName: Classs
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:57
 * Version: 1.0
 * Description:
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Classs {
    private Integer claId;
    private String claName;
    private String claAddress;
}
