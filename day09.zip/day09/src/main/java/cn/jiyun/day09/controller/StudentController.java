package cn.jiyun.day09.controller;

import cn.jiyun.day09.entity.Student;
import cn.jiyun.day09.service.StudentService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ClassName: StudentController
 * Author:   WGG
 * Date:    2022-09-2022/9/25-20:53
 * Version: 1.0
 * Description:
 */
@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;


    @CrossOrigin
    @RequestMapping("findAll")
    public Object findAll(){
        try {
            return studentService.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            return "失败";
        }
    }



    @CrossOrigin
    @RequestMapping("add")
    public Object add(@RequestBody Student student){
        try {
            studentService.add(student);
            return "添加成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "添加失败";
        }
    }


    @CrossOrigin
    @RequestMapping("edit")
    public Object edit(@RequestBody Student student){
        try {
            studentService.edit(student);
            return "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "修改失败";
        }
    }



    @CrossOrigin
    @RequestMapping("delete/{id}")
    public Object delete(@PathVariable("id") Integer id){
        try {
            studentService.delete(id);
            return "删除成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "删除失败";
        }
    }

}
